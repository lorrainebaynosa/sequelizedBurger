var orm = require("./config/orm.js");

// Find all the pets ordering by the lowest price to the highest price.
orm.selectAndOrder("animal_name", "pets", "price");
// CONTROLLER WILL BE USING THIS MODEL METHOD; AND CALLS IT

// Find a pet in the pets table by an animal_name of Rachel.
orm.selectWhere("pets", "animal_name", "Rachel");

// Find the buyer with the most pets.
orm.findWhoHasMost("buyer_name", "buyer_id", "buyers", "pets");

// ROC
// 1. Modularizing configuration
// Reseach sql injection
// 2. ORM : layer on top of existing database; for each table, you will have a model
// SQL is not code but a query language
// 1. FOUR LAYERS OF VALIDATION :client-side, server-side, and other, and model-based validation
//  we will be using SEQUELIZE for built-in methods for queries, seeding, migration
