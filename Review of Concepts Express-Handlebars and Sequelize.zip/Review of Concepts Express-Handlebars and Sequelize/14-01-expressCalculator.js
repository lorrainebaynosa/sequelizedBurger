// * You will create an Express calculator application with one get route that is able to take in three parameters: an operation and two numbers.
// * There are four operation values which a user may use: addition, subtraction, multiplication, and division.
// * When the route is hit, your browser should display the result of the math operation.
// * For example, when the user goes to the url <http://localhost:3000/add/10/1>, the page should display 11.

// Dependencies
var express = require("express");

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// Create express app instance.
var app = express();

// Routes
app.get("/:operation/:firstNum/:secondNum", function(req, res) {

  // Parameters are received from the URL
  var operation = req.params.operation;

  // Parameters are converted to integers
  var firstNum = parseInt(req.params.firstNum);
  var secondNum = parseInt(req.params.secondNum);
  var result;

  // Switch statement chooses operation based on the operation parameter.
  switch (operation) {
  case "add":
  case "+": // Bonus.  Example:  http://localhost:3002/+/6/4 --> 10
    result = firstNum + secondNum;
    break;
  case "subtract":
  case "-": // Bonus.  Example:  http://localhost:3002/-/6/4 --> 2
    result = firstNum - secondNum;
    break;
  case "multiply":
  case "*": // Bonus.  Example:  http://localhost:3002/*/3/4 --> 12
    result = firstNum * secondNum;
    break;
  case "divide":
  case "/": // Bonus.  This char has to be escaped in the url since slashes separate params
    // Example:  http://localhost:3002/%2F/14/2 --> 7
    result = firstNum / secondNum;
    break;
  default:
    result =
        "Sorry! The only valid operations are add, subtract, multiply, and divide.";
  }

  // We return the result back to the user in the form of a string
  res.send(result.toString());

});

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS:
// app.get("/:operation/:firstNum/:secondNum", where Parameters properties are defined by :
// using express server and instance to send API request to return result of url parameters

// SWITCH STATEMENT
// 1. Javascript SWITCH statement: a) switch expression is evaluated once; b) value of expression is compared with values of each case. If there is a match, the associated block of code is executed.
// Syntax:
// switch(expression){
// case: x: 
  // code block
  // break;
// case: y: 
  // code block
  // break;
// case: z: 
  // code block
  // break;
// }
// 3. break keyword: cause switch statement to "break out" of the switch statement and continue to next block of code. Without the break statement, additional blocks of code may be executed if the evaluation matches the case value.
// 4. switch statement is an alternate to multiple if..else statements

// TESTING CODE ABOVE
// 1. Ensure you're in same directory as expressCalculator.js in terminal/bash
// 2. Ensure dependencies are installed (package.json has dependency for express)
// 3. Ensure dependencies have been installed (you will see express in node_modules)
// 4. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console:nodemon expressCalculator.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node expressCalculator.js`
// Server listening on: http://localhost:8080
// 5. Enter the following GET request in the URL/adddress bar: 
// http://localhost:8080/+/5/10
// RETURNS
// 15 (on web page)
// 6. Enter the following GET request in the URL/adddress bar: 
// http://localhost:8080/[/5/10
// RETURNS
// Sorry! The only valid operations are add, subtract, multiply, and divide.
// 7. ENTER CTRL+C to stop server from listening on PORT
