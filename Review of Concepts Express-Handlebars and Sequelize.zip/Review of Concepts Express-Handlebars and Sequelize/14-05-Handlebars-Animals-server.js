// * You will edit the `server.js` file, the `dog.handlebars` file, and the `index.handlebars` file in an attempt to recreate the application that we demonstrated just a couple of minutes ago. Instructions on what to do are contained within each file you will have to edit.

//   * You won't be using MySQL for this exercise but will instead be using the animals array in the `server.js` file.

// Dependencies
var express = require("express");
var exphbs = require("express-handlebars");

// Create an instance of the express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 3000;

// Set Handlebars as the default templating engine 
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

var animals = [
  {
    animalType: "dog",
    pet: true,
    fierceness: 4
  }, {
    animalType: "cat",
    pet: true,
    fierceness: 10
  }, {
    animalType: "giraffe",
    pet: false,
    fierceness: 4
  }, {
    animalType: "zebra",
    pet: false,
    fierceness: 8
  }, {
    animalType: "lion",
    pet: false,
    fierceness: 10
  }
];

app.get("/dog", function(req, res) {
  // Handlebars requires an object to be sent to the dog handlebars file.
  // Lucky for us, animals[0] is an object!

  // 1. send the dog object from the animals array to the dog handlebars file.
  res.render("dog", animals[0]);
});

app.get("/all-pets", function(req, res) {
  // Handlebars requires an object to be sent to the index handlebars file.

  // 2. Loop through the animals, and send those that are pets to the index handlebars file.
  var data = {
    animals: []
  };

  for (var i = 0; i < animals.length; i += 1) {
    // Get the current animal.
    var currentAnimal = animals[i];

    // Check if this animal is a pet.
    if (currentAnimal.pet) {
      // If so, push it into our data.animals array.
      data.animals.push(currentAnimal);
    }
  }
  res.render("index", data);
});
// ALTERNATIVELY, we can code this GET REQUEST ("/all-pets" path) as 
// app.get("/all-pets", function(req, res) {
//   // Handlebars requires an object to be sent to the index.handlebars file.
//   // 2. Send the animals to the index.handlebars file. Remember that animals is an array and not an object.
//   var allPets = [];
//   for (var i = 0; i < animals.length; i++){
//     if (animals[i].pet ===true) {
//       allPets.push(animals[i]);
//     }
//   }
//   res.render("index", {pets: allPets});
// });
// handlebars only accepts OBJECTS {pets: allPets}


app.get("/all-non-pets", function(req, res) {
  // Handlebars requires an object to be sent to the index handlebars file.

  // 3. Loop through the animals, and send those that are not pets to the index handlebars file. Send the animals to the index.handlebars file. Remember that animals is an array and not an object.
  var data = {
    animals: []
  };
  for (var i = 0; i < animals.length; i += 1) {
    // Get the current animal.
    var currentAnimal = animals[i];

    // Check if this animal is a pet.
    if (!currentAnimal.pet) {
      // If not, push it into our data.animals array.
      data.animals.push(currentAnimal);
    }
  }
  res.render("index", data);
});

// ALTERNATIVELY, we can code this GET REQUEST ("/all-non-pets") as
// app.get("/all-non-pets", function(req, res) {
//   // Handlebars requires an object to be sent to the index.handlebars file.
//   // 3. Send all the animals that are not pets to the index.handlebars file.
//   var nonPets = [];
//   for (var i=0; i<animals.length; i++){
//     if (animals[i].pet ===false) {
//       nonPets.push(animals[i]);
//     }
//   }
//   res.render("index", {pets: nonPets});
// });

app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS:
// 1. "render" will automatically look into views directory
// 2. same concepts as activity 04-HandlebarsLunch

// TESTING THIS CODE
// We are using express npm to run an express instance to send GET requests to the data located in server.js file; in the callback function for the (3) GET requests, we specify how we want the page to display in the browser NOT via the html variable as in previous activities but by using server-side templates from handlebars. The content for the app's dog and index views will be rendered into the main layout's  {{{body}}} as specified by the GET request.
// 1. In order to test this code, we must have the following: 
// 2. Ensure you're in same directory as server.js in terminal/bash
// 3. Ensure dependencies are installed (package.json has dependency for express and express-handlebars)
// 4. Ensure dependencies have been installed (you will see express and express-handlebars in node_modules). npm install express and express-handlebars
// 5. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console: nodemon server.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// App listening on PORT 3000
// 6. Enter the following GET request in the URL/adddress bar of the browser: http://localhost:3000/dog (ROUTING)
// RETURNS (on webpage, per dog.handlebars content view)
// Type: dog

// Pet: true

// Fierceness: 4
// 6. Enter the following GET request in the URL/adddress bar of the browser: http://localhost:3000/all-pets (ROUTING)
// RETURNS (on webpage, per index.handlebars content view)
// Type: dog

// Pet: true

// Fierceness: 4

// Type: cat

// Pet: true

// Fierceness: 10

// 7. ENTER CTRL+C to stop server from listening on PORT

