//   * Create a Node Application with Express and MySQL with three Express routes.

// Dependencies
var express = require("express");
var mysql = require("mysql");

// Create instance of express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// MySQL DB Connection Information (remember to change this with our specific credentials)
var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  password: "lazyjack",
  database: "seinfeld_db"
});

// Initiate MySQL Connection.
connection.connect(function(err) {
  if (err) {
    console.error("error connecting: " + err.stack);
    return;
  }
  console.log("connected as id " + connection.threadId);
});

// Routes
// Create a `/cast` route that will display all the actors and their data ordered by their id's.
app.get("/cast", function(req, res) {
  connection.query("SELECT * FROM actors order by id", function(err, result) {
    var html = "<h1>Actors Ordered BY ID</h1>";

    html += "<ul>";

    for (var i = 0; i < result.length; i++) {
      html += "<li><p> ID: " + result[i].id + "</p>";
      html += "<p> Name: " + result[i].name + "</p>";
      html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
      html += "<p>Attitude: " + result[i].attitude + "</p></li>";
    }

    html += "</ul>";

    res.send(html);
  });
});

//   * Create a `/coolness-chart` route that will display all the actors and their data ordered by their coolness points.
app.get("/coolness-chart", function(req, res) {
  connection.query("SELECT * FROM actors order by coolness_points DESC", function(err, result) {
    var html = "<h1>Actors by Coolness</h1>";

    html += "<ul>";

    for (var i = 0; i < result.length; i++) {
      html += "<li><p> ID: " + result[i].id + "</p>";
      html += "<p> Name: " + result[i].name + "</p>";
      html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
      html += "<p>Attitude: " + result[i].attitude + "</p></li>";
    }

    html += "</ul>";

    res.send(html);
  });
});

//  Create a `/attitude-chart/:att` route that will display all the actors for a specific type of attitude.
app.get("/attitude-chart/:att", function(req, res) {
  connection.query("SELECT * FROM actors where attitude = ?", [req.params.att], function(err, result) {
    var html = "<h1>Actors With an Attitude of " + req.params.att + "</h1>";

    html += "<ul>";

    for (var i = 0; i < result.length; i++) {
      html += "<li><p> ID: " + result[i].id + "</p>";
      html += "<p> Name: " + result[i].name + "</p>";
      html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
      html += "<p>Attitude: " + result[i].attitude + "</p></li>";
    }

    html += "</ul>";

    res.send(html);
  });
});

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// TESTING THIS CODE
// We are using express npm to run an express instance to send GET requests to mySQL database via connection to mySQL database via mysql npm package; in the callback function for the (3) GET requests, we specify how we want the page to display in the browser via the html variable.
// 1. In order to test this code, we must have the following: 
// mySQL Workbench: 1) "seinfeld_db" executed per schema.sql; 2) created a connection or instance to the mySQLWorkbench via local host & port 3306; 3) specify password
// 2. Ensure you're in same directory as server.js in terminal/bash
// 3. Ensure dependencies are installed (package.json has dependency for express and mysql)
// 4. Ensure dependencies have been installed (you will see express and mysql in node_modules)
// 5. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console:nodemon server.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node seinfeld.js`
// Server listening on: http://localhost:8080
// connected as id 9
// 6. Enter the following GET request in the URL/adddress bar: 
// http://localhost:8080/cast (ROUTING)
// RETURNS (on webpage):
// Actors Ordered BY ID
// ID: 1

// Name: Jerry

// Coolness Points: 90

// Attitude: relaxed

// ID: 2

// Name: Elaine

// Coolness Points: 80

// Attitude: righteous

// ID: 3

// Name: Kramer

// Coolness Points: 20

// Attitude: doofus

// ID: 4

// Name: George

// Coolness Points: 70

// Attitude: selfish
// 6. Enter the following GET request in the URL/adddress bar: 
// http://localhost:8080/attitude-chart/relaxed (ROUTING)
// RETURNS (on webpage):
// Actors With an Attitude of relaxed
// ID: 1

// Name: Jerry

// Coolness Points: 90

// Attitude: relaxed
// req.params.att is user entry into URL, specifying type of attitude to be queried

// if we enter a path in url/address bar that is not defined in the GET request (e.g., http://localhost:8080/attitude-chart/), the following ERROR message renders to the webpage: Cannot GET /attitude-chart/

// 7. ENTER CTRL+C to stop server from listening on PORT