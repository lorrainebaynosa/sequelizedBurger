// * In this activity, you are going to be creating your own Ben and Jerry's App where users can see all of the different flavors Ben and Jerry's have to offer while also getting specific information on a flavor by searching for it within the URL.

// ```
// var icecreams = [
//   {name: 'vanilla', price: 10, awesomeness: 3},
//   {name: 'chocolate', price: 4, awesomeness: 8},
//   {name: 'banana', price: 1, awesomeness: 1},
//   {name: 'greentea', price: 5, awesomeness: 7},
//   {name: 'jawbreakers', price: 6, awesomeness: 2},
// ];
// ```

// * Do not use MySQL for this assignment! Use the `icecreams` variable above as your data. Add the variable to your `server.js` file.

// Dependencies
var express = require("express");
var exphbs = require("express-handlebars");

// Create an instance of the express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// Set Handlebars as the default templating engine.
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

// Data
var icecreams = [
  { name: "vanilla", price: 10, awesomeness: 3 },
  { name: "chocolate", price: 4, awesomeness: 8 },
  { name: "banana", price: 1, awesomeness: 1 },
  { name: "greentea", price: 5, awesomeness: 7 },
  { name: "jawbreakers", price: 6, awesomeness: 2 },
  { name: "vanilla", price: 10, awesomeness: 3 }
];

// Routes
// * Using handlebars and express, create a route called `/icecream/:name`. When the route is hit, it will display the name, price and awesomeness for that specific ice cream.
app.get("/icecream/:name", function(req, res) {
  for (var i = 0; i < icecreams.length; i++) {
    if (icecreams[i].name === req.params.name) {
      return res.render("icecream", icecreams[i]);
    }
  }
});



// * Create an `/icecreams` route. It will loop over all the ice creams and display them all to the user.
app.get("/icecreams", function(req, res) {
  res.render("ics", { ics: icecreams });
});
// REVIEW OF CONCEPTS: 
// render the page with template "ics"

// Start our (express) server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEOW OF CONCEPTS:
// express & express-handlebars are also installed in node_modules

// Node.js) is an open-source, cross-platform, runtime environment that allows developers to create all kinds of server-side tools and applications in JavaScript. The runtime is intended for use outside of a browser context 
// EXPRESS
// Express is the most popular Node web framework, and is the underlying library for a number of other popular Node web frameworks. It provides mechanisms to: 1) Write handlers for requests with different HTTP verbs at different URL paths (routes). 2) Integrate with "view" rendering engines in order to generate responses by inserting data into templates.
// 3) Set common web application settings like the port to use for connecting, and the location of templates that are used for rendering the response. 4) Add additional request processing "middleware" at any point within the request handling pipeline. Express provides methods to specify what function is called for a particular HTTP verb (GET, POST, SET, etc.) and URL pattern ("Route"), and methods to specify what template ("view") engine is used, where template files are located, and what template to use to render a response. You can use Express middleware to add support for cookies, sessions, and users, getting POST/GET parameters, etc. With express HTTP utility methods & middleware, we can create APIs. 
// https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs/Introduction

// https://www.npmjs.com/package/express-handlebars: 
// EXPRESS HANDLEBARS 
// A handlebars view engine for express; 
// Basic structure
// ├── app.js (server.js)
// └── views
//     ├── home.handlebars 
//     └── layouts
//         └── main.handlebars

// app.js(server.js): Creates a super simple Express app which shows the basic way to register a Handlebars view engine using this package.

// views/layouts/main.handlebars:
// The main layout is the HTML page wrapper which can be reused for the different views of the app. {{{body}}} is used as a placeholder for where the main content should be rendered.

// views/home.handlebars:
// The content for the app's home view which will be rendered into the layout's {{{body}}}.
// <h1>Example App: Home</h1>


// _dirname: root directory of node app
// / homepage