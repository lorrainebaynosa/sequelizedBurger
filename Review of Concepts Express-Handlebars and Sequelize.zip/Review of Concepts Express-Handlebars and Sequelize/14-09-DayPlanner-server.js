// Dependencies
var express = require("express");
var exphbs = require("express-handlebars");
var mysql = require("mysql");

// Create an instance of the express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// Parse request body as JSON; sets up the Express app to handle data parsing (MIDDLEWARE)
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set Handlebars as the default templating engine 
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");


// MySQL DB Connection Information (remember to change this with our specific credentials)
var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  password: "lazyjack",
  database: "day_planner_db"
});

connection.connect(function(err) {
  if (err) {
    console.error("error connecting: " + err.stack);
    return;
  }

  console.log("connected as id " + connection.threadId);
});

// Use Handlebars to render the main index.html page with the todos in it.
app.get("/", function(req, res) {
  connection.query("SELECT * FROM plans;", function(err, data) {
    if (err) {
      return res.status(500).end();
    }

    res.render("index", { plans: data });
  });
});
// REVIEW OF CONCEPTS: 
// 1. matches "get http method" and path "/"

// Create a new todo
app.post("/todos", function(req, res) {
  connection.query("INSERT INTO plans (plan) VALUES (?)", [req.body.plan], function(err, result) {
    if (err) {
      return res.status(500).end();
    }

    // Send back the ID of the new todo
    res.json({ id: result.insertId });
    console.log({ id: result.insertId });
  });
});

// Update a todo
app.put("/todos/:id", function(req, res) {
  connection.query("UPDATE plans SET plan = ? WHERE id = ?", [req.body.plan, req.params.id], function(err, result) {
    if (err) {
      // If an error occurred, send a generic server failure
      return res.status(500).end();
    }
    else if (result.changedRows === 0) {
      // If no rows were changed, then the ID must not exist, so 404
      return res.status(404).end();
    }
    res.status(200).end();

  });
});
// ROC: 
// req.body.plan: retrieving data from data being passed in (generally via user submission (e.g., via form on webpage or Postman content box)); ideal for large amounts of data (e.g., JSON data)
// req.params.id: retrieving data from URL (ideal for smaller, more specific data)
// data must have id in order to know what to update & delete



// Delete a todo
app.delete("/todos/:id", function(req, res) {
  connection.query("DELETE FROM plans WHERE id = ?", [req.params.id], function(err, result) {
    if (err) {
      // If an error occurred, send a generic server failure
      return res.status(500).end();
    }
    else if (result.affectedRows === 0) {
      // If no rows were changed, then the ID must not exist, so 404
      return res.status(404).end();
    }
    res.status(200).end();

  });
});

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS
// 1. Data from the database is stored in variable data while parameter "result" is passed in callback function for connection.query in post request


// REVIEW OF CONCEPTS: TESTING CODE ABOVE with NODEMON (ensure we're in same directory as server.js)
// 1. Enter the following in the terminal: nodemon server.js
// 2. RETURNS following in terminal: [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// Server listening on: http://localhost:8080
// connected as id 117
// 3. TESTING THIS CODE, we enter the following into the url/address bar in Chrome browser: http://localhost:8080/ 
// 3a. DISPLAYS the following on the browser page:
// Day Planner
// 1. Plan to fight a ninja.  Delete Plan!

// Create a Plan
//   Save Plan!
// Update a Plan
  
// plan
//   Update Plan!

// b. notice everytime we save, the id with which we are connected incrementally increases ++

