// *****************************************************************************
// Server.js - This file is the initial starting point for the Node/Express server.
//ROC: SIMILAR TO ACTIVITY 10-11
// ******************************************************************************
// *** Dependencies
// =============================================================
var express = require("express");

// Sets up the Express App
// REVIEW OF CONCEPTS: 
// 1. Initialzies app
// =============================================================
var app = express();
var PORT = process.env.PORT || 8080;

// Requiring our models for syncing
var db = require("./models");

// Sets up the Express app to handle data parsing
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static directory
app.use(express.static("public"));

// Routes
// =============================================================
require("./routes/api-routes.js")(app);
require("./routes/html-routes.js")(app);

// Syncing our sequelize models and then starting our Express app
// =============================================================
db.sequelize.sync({ force: true }).then(function() {
  app.listen(PORT, function() {
    console.log("App listening on PORT " + PORT);
  });
});

// REVIEW OF CONCEPTS:
// https://www.youtube.com/watch?v=bOHysWYMZM0
// 1. Sequelize is a promise-based ORM for Node.js v4 and up, supporting dialects such as mySQL, PostgreSQL, MSSQL, and SQLite,
// 2. app.listen(PORT, function() {} runs the server (5000 if local server;  process.env.PORT for use with Heroku)
// 3. MVC: In order for the local server to run, we must initialize the app, require the db variable which will give us the MODEL which will interact with the database schema.sql as the user will be requesting data via a route
// 4. routes are necessary as the url link dictates the specific CONTROLLER METHOD to be called

// TEST THIS CODE
// On terminal, run 
// 1. npm init to create package.json file; 2) npm install express mysql2 sequelize 
// 2. In config.json file, update password to your mySQLWorkbench info: password, database to the name of the database the model will be interacting with, and port for your local instance to run the mySQL server. Dialect should be mysql - not mysql2
// // {
//   "development": {
//     "username": "root",
//     "password": "lazyjack",
//     "database": "blogger",
//     "host": "127.0.0.1",
//     "port": 3306,
//     "dialect": "mysql"
//   },
// 3. Ensure the queries to create the blogger database per schema.sql has been run in mySQLWorkbench
// 4. Running server.js in the terminal (ensure you are in the root directory of server.js) RETURNS 
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// sequelize deprecated String based operators are now deprecated. Please use Symbol based operators for better security, read more at http://docs.sequelizejs.com/manual/tutorial/querying.html#operators node_modules/sequelize/lib/sequelize.js:245:13
// Executing (default): DROP TABLE IF EXISTS `Posts`;
// Executing (default): DROP TABLE IF EXISTS `Posts`;
// Executing (default): CREATE TABLE IF NOT EXISTS `Posts` (`id` INTEGER NOT NULL auto_increment , `title` VARCHAR(255) NOT NULL, `body` TEXT NOT NULL, `category` VARCHAR(255) DEFAULT 'Personal', `createdAt` DATETIME NOT NULL, `updatedAt` DATETIME NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB;
// Executing (default): SHOW INDEX FROM `Posts` FROM `blogger`
// App listening on PORT 8080



// EXPRESS-HANDLEBARS: templating engine to display HTML & include dynamic content & loop through data to show output
