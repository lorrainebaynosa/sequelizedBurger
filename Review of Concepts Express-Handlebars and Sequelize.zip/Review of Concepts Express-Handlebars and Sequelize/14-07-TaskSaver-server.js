// Dependencies
var express = require("express");
var exphbs = require("express-handlebars");
var mysql = require("mysql");

// Create an instance of the express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// Sets up the Express app to handle data parsing (MIDDLEWARE)
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set Handlebars as the default templating engine
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");


// MySQL DB Connection Information (remember to change this with our specific credentials)
var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  password: "lazyjack",
  database: "task_saver_db"
});

connection.connect(function(err) {
  if (err) {
    console.error("error connecting: " + err.stack);
    return;
  }

  console.log("connected as id " + connection.threadId);
});

// Root get route
app.get("/", function(req, res) {
  connection.query("SELECT * FROM tasks;", function(err, data) {
    if (err) throw err;

    // Test it
    // console.log('The solution is: ', data);

    // Test it
    // return res.send(data);

    res.render("index", { tasks: data });
  });
});


// CREATE a new task: Post route -> back to home
app.post("/", function(req, res) {
  // Test it
  // console.log('You sent, ' + req.body.task);

  // Test it
  // return res.send('You sent, ' + req.body.task);

  // When using the MySQL package, we'd use ?s in place of any values to be inserted, which are then swapped out with corresponding elements in the array
  // This helps us avoid an exploit known as SQL injection which we'd be open to if we used string concatenation
  // https://en.wikipedia.org/wiki/SQL_injection
  connection.query("INSERT INTO tasks (task) VALUES (?)", [req.body.task], function(err, result) {
    if (err) throw err;

    res.redirect("/");
  });
});
// ROC: redirect essentially renders/displays updated information after routing to "/" during redirect

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});


// REVIEW OF CONCEPTS:
// npm install express and express-handlebars and mysql

// TESTING THIS CODE
// We are using express npm to run an express instance to send a GET request to mySQL database via connection to mySQL database via mysql npm package; in the callback function for the GET request, we specify how we want the page to display in the browser NOT via the html variable as in previous activities but by using server-side templates from handlebars. The content for the app's index views will be rendered into the main layout's  {{{body}}} as specified by the GET request.

// 1. In order to test this code, we must have the following: 
// mySQL Workbench: 1) "task_saver_db" executed per schema.sql; 2) created a connection or instance to the mySQLWorkbench via local host & port 3306; 3) specify password
// 2. Ensure you're in same directory as server.js in terminal/bash
// 3. Ensure dependencies are installed (package.json has dependency for express, express-handlebars, and mysql)
// 4. Ensure dependencies have been installed (you will see express, express-handlebars, and mysql in node_modules)
// 5. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console:nodemon server.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// Server listening on: http://localhost:8080
// connected as id 16
// 6. Enter the following GET request in the URL/adddress bar of the browser: http://localhost:8080/ (ROUTING): 
// RETURNS (on webpage, per index.handlebars content view)
// Task Saver
// Save the tasks you need to get to later
// ID: 1

// Task: Pick up milk.

// ID: 2

// Task: Mow the lawn.

// ID: 3

// Task: Call Shannon back.

//   Submit

// 7. When submitting a new task in webpage rendered above, we send a post request, that adds the task === req.body.task to the mySQL database, the user is then redirected to the /path (root path), with the webpage rendered to the user per get REQUEST with the updated list (new task added). REFRESH schema in mySQLWorkbench to see the updated table.

// 1) USER sees view of application in the BROWSER; 2) USER makes request with input to ROUTER via http://localhost:8080/; 3) ROUTER calls specific CONTROLLER method(s) based on ROUTE; 4) Since data is needed (need to fetch data), CONTROLLER interacts with MODEL. 5) MODEL then interacts with database (DB); 6) DB passes data back to MODEL; 6) When CONTROLLER receives data back from MODEL (the one from the DB), it can load a view per index.handlebars and send the data to the VIEW; 7) VIEW deals with the data from the CONTROLLER via a template engine (e.g., express-handlebars); 8. VIEW sends view back to BROWSER (via CONTROLLER) for user to see with the content view rendered using main.handlebars layout

// REVIEW OF CONCEPTS: 
// 1. Data from the database is stored in variable data while parameter "result" is passed in callback function for connection.query in post request