// Dependencies
// ROC : using express-handlebars npm module
var express = require("express");
var exphbs = require("express-handlebars");

// Create an instance of the express app.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku
var PORT = process.env.PORT || 8080;

// Set Handlebars as the default templating engine 
app.engine("handlebars", exphbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

// Data
var lunches = [
  {
    lunch: "Beet & Goat Cheese Salad with minestrone soup.",
    meow: "Gato Frenzy"
  }, {
    lunch: "Pizza, two double veggie burgers, fries with a Big Gulp"
  }
];

// Routes
app.get("/weekday", function(req, res) {
  res.render("index", lunches[0]);
});
// ROC: handlebars files only accept objects; passing 
// 1. passing in lunches[0] with all its properties into index.handlebars
// 2. default layout is "main"
// 3. VIEWS are meant to display - not process
// 4. app.get("/weekday", function(req, res) {
//   res.render("index", lunches[0]);
// }); RENDERS "index" view (1:03:00)

app.get("/weekend", function(req, res) {
  res.render("index", lunches[1]);
});
// ROC: "render" will automatically look into views directory
// 2. Even if have different routes, can use same file, index.handlbars

app.get("/lunches", function(req, res) {
  res.render("all-lunches", {
    foods: lunches,
    eater: "david"
  });
});
// ROC: 
// // 1. res.render("all-lunches", {
//     foods: lunches,
//     eater: "david"
//   });
// passing in an object, where value lunches is an array; and value david is a string; "lunches" represents data (array of objects) that will theoretically come from a database in the future

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS, EXPRESS HANDLEBARS 
// A handlebars view engine for express; 
// Basic structure
// ├── app.js (server.js)
// └── views
//     ├── home.handlebars 
//     └── layouts
//         └── main.handlebars

// app.js(server.js): Creates a super simple Express app which shows the basic way to register a Handlebars view engine using this package.

// views/layouts/main.handlebars:
// The main layout is the HTML page wrapper which can be reused for the different views of the app. {{{body}}} is used as a placeholder for where the main content should be rendered.

// views/home.handlebars:
// The content for the app's home view which will be rendered into the layout's  {{{body}}}.
// <h1>Example App: Home</h1>

// EXPRESS-HANDLEBARS only accepts OBJECTS as the 2nd argument to passed in callback function for get request, where lunches[0] is an object:
// app.get("/weekday", function(req, res) {
//   res.render("index", lunches[0]);
// });


// REVIEW OF CONCEPTS: times from videos are from video https://www.youtube.com/watch?v=L72fhGm1tfE unless otherwise specified 

// 1. app.engine() and app.set() are the middleware to ensure use of express-handlebars, found in documentation for express-handlebars (59:00)
// app.engine("handlebars", exphbs({ defaultLayout: "main" })); sets TEMPLATE ENGINE to "handlebars", and then passing in var exphbs and setting defaultLayout to layout provided in "main.handlebars" file in layouts director
// app.set("view engine", "handlebars"); sets VIEW ENGINE 
// 2. will render all views/templates; handling VIEWS as part of MVC; views is a directory); handlebars engine processes all-lunches.handlebars and index.handlebars
// 3. this is cleaner than adding html files
// 4. render templates so you can insert dynamic data to create a dynamic app vs a static website (21:35). If you need to pass data dynamically into app, you can use server-side templates from handlebars to display info to browser. Advantages of templates: templates can be reused
// 5. Reality: you won't have a JSON API (e.g, with REACT or VUE on the front-end & you're just serving JSON) & server-rendered templates (e.g., server-sided app where you just use templates). You'll usually just use one. 
// 6. Part of MVC model: processing is done before passing data into views


// TESTING THIS CODE
// We are using express npm to run an express instance to send GET requests to the data located in server.js file; in the callback function for the (3) GET requests, we specify how we want the page to display in the browser NOT via the html variable as in previous activities but by using server-side templates from handlebars. The content for the app's all-lunches and index views will be rendered into the main layout's  {{{body}}} as specified by the GET request.
// 1. In order to test this code, we must have the following: 
// 2. Ensure you're in same directory as server.js in terminal/bash
// 3. Ensure dependencies are installed (package.json has dependency for express and express-handlebars)
// 4. Ensure dependencies have been installed (you will see express and express-handlebars in node_modules)
// 5. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console:nodemon server.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// Server listening on: http://localhost:8080
// 6. Enter the following GET request in the URL/adddress bar of the browser: http://localhost:8080/weekday (ROUTING)
// RETURNS (on webpage): 
// Beet & Goat Cheese Salad with minestrone soup.
// "Hi my lunch is Beet & Goat Cheese Salad with minestrone soup..
// Gato Frenzy
//  as GET request specifies that content should be viewed as specified by the index.handlebars template with final rendering of content per layout in main.handlebars

// 7. Enter the following GET request in the URL/adddress bar of the browser: http://localhost:8080/weekend (ROUTING)
// RETURNS (on webpage): 
// Pizza, two double veggie burgers, fries with a Big Gulp
// "Hi my lunch is Pizza, two double veggie burgers, fries with a Big Gulp

// 8. Using a different views template (all-lunches.handlebars) with final rendering of content per layout in main.handlebars: 
// Enter the following GET request in the URL/adddress bar of the browser: http://localhost:8080/lunches (ROUTING)
// RETURNS (on webpage): 
// Lunches for david
// Beet & Goat Cheese Salad with minestrone soup.
// 
// Pizza, two double veggie burgers, fries with a Big Gulp

// 9. ENTER CTRL+C to stop server from listening on PORT
