// Dependencies
var express = require("express");
var mysql = require("mysql");

// Create express app instance.
var app = express();

// Set the port of our application
// process.env.PORT lets the port be set by Heroku (not used by local machine but only used if we need to deploy it)
var PORT = process.env.PORT || 8080;

// MySQL DB Connection Information (remember to change this with our specific credentials)
var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,
  // port for database server in mySQLWorkbench
  user: "root",
  password: "lazyjack",
  database: "wizard_schools_db"
});

// Initiate MySQL Connection.
connection.connect(function(err) {
  if (err) {
    console.error("error connecting: " + err.stack);
    return;
  }
  console.log("connected as id " + connection.threadId);
});

// Routes
// ROC: http method must match .get/.post and path
app.get("/", function(req, res) {

  // If the main route is hit, then we initiate a SQL query to grab all records.
  // All of the resulting records are stored in the variable "result."
  connection.query("SELECT * FROM schools", function(err, result) {

    // We then begin building out HTML elements for the page.
    var html = "<h1> Magical Schools </h1>";

    // Here we begin an unordered list.
    html += "<ul>";
    // ROC: BUILDING HTML VARIABLE

    // We then use the retrieved records from the database to populate our HTML file.
    for (var i = 0; i < result.length; i++) {
      html += "<li><p> ID: " + result[i].id + "</p>";
      html += "<p>School: " + result[i].name + " </p></li>";
    }

    // We close our unordered list.
    html += "</ul>";

    // Finally we send the user the HTML file we dynamically created.
    res.send(html);
  });
});

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// TESTING THIS CODE
// We are using express npm to run an express instance to send a GET request to mySQL database via connection to mySQL database via mysql npm package; in the callback function for the GET request, we specify how we want the page to display in the browser via the html variable.
// 1. In order to test this code, we must have the following: 
// mySQL Workbench: 1) "wizard_schools_db" executed per schema.sql; 2) created a connection or instance to the mySQLWorkbench via local host & port 3306; 3) specify password
// 2. Ensure you're in same directory as magicSchools.js in terminal/bash
// 3. Ensure dependencies are installed (package.json has dependency for express and mysql)
// 4. Ensure dependencies have been installed (you will see express and mysql in node_modules)
// 5. To avoid having to restart server manually, use nodemon and enter the following in terminal/bash console:nodemon magicSchools.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node magicSchools.js`
// Server listening on: http://localhost:8080
// connected as id 5

// 6. Enter the following GET request in the URL/adddress bar: 
// http://localhost:8080/
// RETURNS (on webpage)
// Magical Schools
// ID: 1

// School: Hogwarts School of Witchcraft

// ID: 2

// School: Castelobruxo

// ID: 3

// School: Durmstrang Institute

// ID: 4

// School: Beauxbatons Academy of Magic

// 7. ENTER CTRL+C to stop server from listening on PORT
